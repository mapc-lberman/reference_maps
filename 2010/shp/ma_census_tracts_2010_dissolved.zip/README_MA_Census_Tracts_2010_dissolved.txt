MA_Census_Tracts_2010_dissolved


All 2010 census tracts dissolved into a single multi-polygon feature.

This includes offshore islands.


The purpose of this file is to provide a clipping boundary, as described in the 2020 Census Tracts cleanup process [ reference_maps/2020/shp/2020_census_tracts_shp.pdf ].


Similarly, this is convenient to clip any objects to the Massachusetts extent that are based on 2010 Census geographies.   

For example the UMN Accessibility Observatory data for the two regions 14460 Boston - NH, and 39300 Providence - Fall River, can be selected to the extent of Mass using this boundary file.  