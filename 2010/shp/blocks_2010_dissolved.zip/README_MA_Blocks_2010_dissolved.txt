MA_blocks_2010_dissolved


All 2010 census blocks dissolved into a single multi-polygon feature.

This includes offshore islands.


The purpose of this file is to provide a clipping boundary, for example the UMN Accessibility Observatory data for the two regions 14460 Boston - NH, and 39300 Providence - Fall River, were clipped to the extent of Mass using this boundary file.  